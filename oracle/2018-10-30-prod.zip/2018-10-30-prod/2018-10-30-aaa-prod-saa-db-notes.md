# prod replication halt for BR

## pre-stop checks

sequences comparison

```
select sequence_name, min_value, increment_by, last_number from user_sequences order by sequence_name;
```

### sequences diff

```
CREATE SEQUENCE SR4UAT.PSS_FAIL_SEQ MINVALUE 1 MAXVALUE 9999999999999999999999999999 INCREMENT BY 1 START WITH 1 NOCACHE NOORDER NOCYCLE;
```

### check dms replication

https://ap-southeast-1.console.aws.amazon.com/dms/home?region=ap-southeast-1#

prod-sr4uat-blob-tables
prod-sr4uat-main-tables
prod-sr4uat-misc1-tables
prod-sr4uat-misc2-tables
prod-sr4uat-transaction-tables

## sequence adjuster

Working generator for sequence adjustment:

```
select 'ALTER SEQUENCE sr4uat.'||sequence_name||' INCREMENT BY 1000000;' || chr(10) ||'SELECT sr4uat.'||sequence_name||'.NEXTVAL FROM dual;' || chr(10) ||'ALTER SEQUENCE sr4uat.'||sequence_name||' INCREMENT BY 1;' from user_sequences where increment_by=1 order by sequence_name;
```

## diff everything

Ignorig IWTEMP* tables. Saved to 2018-10-30-export-iwtemp.sql for reference.

## order of execution

indexes before alter table statements, else you get errors due to missing fileds

## duplicates

```
select ID, count(ID) from SAA_FLIGHT_SEGMENT group by ID having count (ID) > 1;
```

```
delete from SAA_FLIGHT_SEGMENT where ID=900174477
```

## sequences check

ADDON_DETAILS_ID
AUD_LOG_ID
HIBERNATE_SEQUENCE
MASTER_DATA_LOOKUP_SEQ
SAA_CMT_PROFILE_SEQ
SAA_KF_TRACKING_FROM_EDM_SEQ
SAA_KRISSHOP_KF_DETAILS_SEQ
SEQ_BWFG_SEQUENCE
SEQ_KF_MILEACCRUAL
SEQ_SAA_PAYMENT_OPTION

select 'ALTER SEQUENCE sr4uat.'||sequence_name||' INCREMENT BY 1000000;' || chr(10) ||'SELECT sr4uat.'||sequence_name||'.NEXTVAL FROM dual;' || chr(10) ||'ALTER SEQUENCE sr4uat.'||sequence_name||' INCREMENT BY 1;' from user_sequences where increment_by=1 order by sequence_name;

## Data Cleanup

`delete from SAA_FLIGHT_SEGMENT where ID=900174477 and SEGMENT_ID=1;`

`ALTER TABLE "SR4UAT"."SAA_FLIGHT_SEGMENT" MODIFY CONSTRAINT "SYS_C0041776" ENABLE;`

